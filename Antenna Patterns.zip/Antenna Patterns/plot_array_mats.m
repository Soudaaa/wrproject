clc; clear; close all;

%------ Select Pattern -----%
load ideal_pattern_Norm_final.mat
% load error_pattern_Norm_final_Crapy1.mat
% load errorPatternCrappy2.mat


%------ Process and Normalize Arrays -----%
lpat2 = 10*log10(abs(pat2));
lpat2 = lpat2 - max(max(lpat2));

%------ Steering Angle -----%
AZ = 0; % in degrees
EL = 0; % in degrees
IDEAL = 0;
%------ Radar Params-----%
c = 2.997925e8;
f = 3.07*1e9;  %frequency
lam = c./f;    %wavelength
n = size(lpat2,2);      %UV size
delta_x_deg = 180/(n+1);
delta_y_deg = 180/(n+1);

% Panel size
panel_row = 5; % total panels in x
panel_col = 5; % total panels in y
elem_per_panel_x = 8; % elements per panel x
elem_per_panel_y = 8; % elements per panel y
dx = lam/2;
dy = lam/2;
elarea = dx*dy;

nx = panel_row*elem_per_panel_x;
ny = panel_col*elem_per_panel_y;

[elem_loc, panel_loc, msk] = array_geometry_fun(panel_row, panel_col, elem_per_panel_x, elem_per_panel_y, dx, dy, lam, 2);
% Compute beam-shaping mask
u = lam./dx/2*(-n/2:n/2-1)*2/n;
v = lam./dy/2*(-n/2:n/2-1).'*2/n;
[az,~]=UV2degrees(u,0);
[~,el]=UV2degrees(0,v);


[xi,yi] = meshgrid(-8:0.05:8, -8:0.05:8);
zi = griddata(az,el,lpat2,xi,yi,'cubic');
zis = imgaussfilt(zi,[5 5],'FilterSize',[11 11]);
Gnorm = max(zis(:));
zis = zis - Gnorm;

%
close all

figure()
subplot(1,3,1);
plot(az,lpat2(n/2,:).','LineWidth',3,'DisplayName','Azimuth')
hold
plot(el,lpat2(:,n/2).','--','LineWidth',3,'DisplayName','Elevation')
axis square;
xlim([-60 60]); ylim([-35 0]);
% title(sprintf('Horus 2D Two-way Pattern'));
set(gca,'linewidth',2,'Fontsize',16,'FontName','Times New Roman');
xlabel('(\circ)');ylabel('(dB)')
legend

subplot(1,3,2);
surf(az,el,lpat2.'); shading interp; hold on; 
%hold on; henv = surf(az,el,20*log10(patmsklin)); shading interp; axis tight;
%set(henv,'FaceColor',[0 0 1],'FaceAlpha',0.5,'FaceLighting','gouraud','EdgeColor','none');
xlabel('Elevation (\circ)'); ylabel('Azimuth (\circ)');  zlabel('Normalized Gain (dB)');
camlight(40,10);%title(sprintf('Horus 3D Two-way Pattern')); 
caxis([-35 0]); zlim([-35 0]); hold off; colormap(jet(100)); axis square;
set(gca,'linewidth',2,'Fontsize',16,'FontName','Times New Roman');
view([50 10]); xlim([-30 30]); ylim([-30 30]);
xticks([-75:15:75]); yticks([-75:15:75]);
cc=colorbar; set(get(cc,'ylabel'),'string','dB');view([0 90]);

subplot(1,3,3);
% surf(xi,yi,zis); axis equal; view([0 90]); hold on; shading flat; 
surf(az,el,lpat2.'); shading interp; hold on; view([0 90]);
axis([-7 7 -7 7]); colormap(jet(100)); cb = colorbar;
xlabel('Elevation (\circ)'); ylabel('Azimuth (\circ)');  zlabel('Normalized Gain (dB)');
box on; %title(sprintf('Horus Two-way Pattern Mainbeam')); 
caxis([-25 0]); zlim([-25 0]); axis square; set(gcf,'color','w');
set(gca,'linewidth',2,'Fontsize',16,'FontName','Times New Roman');
cc=colorbar; set(get(cc,'ylabel'),'string','dB');
xticks([-5:2.5:5]); yticks([-5:2.5:5]);
[Ch,~]=contour3(yi,xi,zis+3,'LevelList',0,'linestyle','--','linewidth',1.5);





function [elem_loc, panel_loc, msk] = array_geometry_fun(panels_x,panels_y,elem_panel_x,elem_panel_y, dx, dy, lam, geo_type)

    plot_geom = 0;
    % geo_type:
    %   Rectangular Geometry = 1
    %   Approximate Circular Geometry = 2
    %   True Circular Geometry = 3
    
    nr = ones(1,panels_x)*panels_x;
    nc = ones(1,panels_y)*panels_y;
    yr = -(nr-1)/2:(nr-1)/2;
    xc = [];
    yc = [];
    for ii=1:nr
        % Panel locations (in units of panels)
        xc0 = -(nc(ii)-1)/2:(nc(ii)-1)/2;
        yc0 = yr(ii).*ones(size(xc0));
        xc = [xc xc0];
        yc = [yc yc0];
    end
    %Panel locations in units of elements
    x0u = xc*elem_panel_x;
    y0u = yc*elem_panel_y;
    
    nx = panels_x*elem_panel_x;
    ny = panels_y*elem_panel_y;
    xv = ((1:nx)-(nx+1)/2)*dx;
    yv = (((1:ny)-(ny+1)/2)*dy).';
    xm = (ones(ny,1)*xv);
    ym = (yv*ones(1,nx));
    
    % Cut out panels outside of radius
    if geo_type == 2
        r = sqrt((ones(panels_y,1)*unique(x0u)).^2 + (unique(y0u).'*ones(1,panels_x)).^2);
        normr = r./max(x0u);  %Normalized r (from 0 to 1);
        maxr = 0.76*max(r(:));
        ind = find(r <= maxr);
        msk = zeros(panels_y,panels_x);
        msk(ind) = ones(size(ind));
        x0u(~msk) =[];
        y0u(~msk) =[];
    end
    panel_loc(1,:) = dx*x0u;
    panel_loc(2,:) = dy*y0u;
    
    %Make panels at all of the locations
    elem_loc = [];
    for ii=1:length(x0u)
        elem_loc = [elem_loc mkpnl_arr(x0u(ii)*dx,y0u(ii)*dy,dx,dy,elem_panel_x,elem_panel_y)];
    end
    
    if geo_type == 3
        % Cut out elements outside of radius
        r = sqrt(elem_loc(1,:).^2 + elem_loc(2,:).^2);
        normr = r./max(xv);  %Normalized r (from 0 to 1);
        maxr = max(xv)+0.5*dx;
        ind = find(r <= maxr);
        msk = zeros(1,size(elem_loc,2));
        msk(ind) = ones(size(ind));
        elem_loc(:,~logical(msk)) = [];
        % Cut out panel locations outside the radius
        r = lam/2*sqrt((ones(panels_y,1)*unique(x0u)).^2 + (unique(y0u).'*ones(1,panels_x)).^2) - panels_x*dx/2;
        normr = r./max(x0u) + 0.5; % Normalized r (from 0 to 1);
        ind = find(r <= maxr);
        msk = zeros(panels_y,panels_x);
        msk(ind) = ones(size(ind));
        x0u(~msk) =[];
        y0u(~msk) =[];
    end
    
    msk = zeros(ny,nx);
    for ii=1:size(elem_loc,2)
        i0 = find(abs(elem_loc(1,ii)-xv)<dx/10);
        j0 = find(abs(elem_loc(2,ii)-yv)<dy/10);
        msk(j0,i0) = 1;  %Uniform taper (tx)
    end
    
    if plot_geom
        figure;
        plot(elem_loc(1,:),elem_loc(2,:),'.b','MarkerSize',5.5); hold on; axis equal;
        plot(x0u*dx,y0u*dy,'.','color',[200 120 50]./255,'markersize',18); hold on
        xlabel('{\itx} (m)'); ylabel('{\ity} (m)');
        title([ num2str(length(x0u)) ' panels']);
        for ii=1:size(panel_loc,2)
            plot((x0u(ii)+[-elem_panel_x/2 elem_panel_x/2 elem_panel_x/2 -elem_panel_x/2 -elem_panel_x/2])...
                *dx,(y0u(ii)+[-elem_panel_y/2 -elem_panel_y/2 elem_panel_y/2 elem_panel_y/2 -elem_panel_y/2])*dy,'k','linewidth',2)
            if(ii==1), hold on; end
        end
        Lx = panels_x*(elem_panel_x*dx);
        Ly = panels_y*(elem_panel_y*dy);
        %     axis tight;
        axis([-Lx/2-dx Lx/2+dx -Ly/2-dy Ly/2+dy]);
        set(gca,'linewidth',2,'Fontsize',20,'FontName','Times New Roman'); box on
    end
end


function [cds] = mkpnl_arr(x0,y0,dx,dy,panel_row,panel_col)
    %generate a panel
    nx = panel_row;
    ny = panel_col;
    cds = [];
    for ii=1:ny
       x = x0+(-(nx-1)/2:(nx-1)/2)*dx;
       y = y0+ones(1,ny)*(-(ny-1)/2 + (ii-1))*dy;
       cds = [cds [x; y]];
    end
end

function [azimuth_deg, elevation_deg] = UV2degrees(U, V)
    % Convert from U and V space to Azimuth and Elevation
    elevation_rad       = asin(V);
    azimuth_rad         = atan2(U,sqrt(1-U.^2-V.^2));
    
    % Convert Azimuth and Elevation from Radians to Degrees
    elevation_deg       = elevation_rad.*180/pi;
    azimuth_deg         = azimuth_rad.*180/pi;
end